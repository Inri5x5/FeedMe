import React from 'react'
import PropTypes from 'prop-types';

const TagCheckBox = (props) => {
    
    return (
        <>
            
        </>
    )
}

TagCheckBox.propsTypes = { 
    TagsList: PropTypes.object,
    
}

export default TagCheckBox;