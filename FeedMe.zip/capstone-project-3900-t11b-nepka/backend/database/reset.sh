#!/bin/bash

python convert_sprint_one_data.py
python schemas_sprint_two_data.py
python generate_recipe_data0.py
python generate_user_data.py
python schemas_sprint_three_data.py
python generate_search_data.py
python generate_video_data.py
python generate_recipe_data1.py
python generate_recipe_data2.py
python generate_recipe_data3.py